"""Run once each trading day around 9:20 IST (after market open):
   uses yesterday's completed daily bar for signals, as in the backtest."""
import json, os
from datetime import date
import pandas as pd
import requests
import config as C
import data as D
from strategy import add_signals
from risk import position_size, halted, kill_switch
from broker import PaperBroker, KiteBroker

STATE_FILE = f"state_{C.MODE}.json"


def notify(msg):
    print(msg)
    if C.TELEGRAM_TOKEN and C.TELEGRAM_CHAT_ID:
        try:
            requests.post(f"https://api.telegram.org/bot{C.TELEGRAM_TOKEN}/sendMessage",
                          data={"chat_id": C.TELEGRAM_CHAT_ID, "text": msg}, timeout=10)
        except Exception as e:
            print("telegram failed:", e)


def load_state():
    if os.path.exists(STATE_FILE):
        return json.load(open(STATE_FILE))
    return {"cash": C.CAPITAL, "positions": {}, "peak": C.CAPITAL, "last_bar": ""}


def main():
    if C.MODE not in ("paper", "live"):
        raise SystemExit("MODE must be 'paper' or 'live' for bot.py (use backtest.py for backtests)")
    if kill_switch():
        return notify("KILL file found. Bot stopped.")
    if date.today().weekday() >= 5:
        return

    state = load_state()
    pos = state["positions"]
    broker = PaperBroker(state) if C.MODE == "paper" else KiteBroker(state)

    sig = {}
    for s in C.SYMBOLS:
        df = D.load(s, years=2)
        df = df[df.index.date < date.today()]          # drop today's partial bar
        sig[s] = add_signals(df)
    bar = max(str(d.index[-1].date()) for d in sig.values())
    if bar == state["last_bar"]:
        return notify(f"No new bar since {bar} (holiday or already run).")
    prev = pd.Timestamp(state["last_bar"]) if state["last_bar"] else None

    # stopped-out positions
    if C.MODE == "paper" and prev is not None:
        for s in list(pos):
            new = sig[s][sig[s].index > prev]
            hit = new[new.Low <= pos[s]["stop"]]
            if len(hit):
                px = min(hit.iloc[0].Open, pos[s]["stop"])
                broker.state["cash"] += pos[s]["qty"] * px
                notify(f"STOP {s} x{pos[s]['qty']} @ {px:.2f} on {hit.index[0].date()}")
                del pos[s]
    elif C.MODE == "live":
        held = broker.held()
        for s in list(pos):
            if s not in held:
                notify(f"{s} no longer held at broker (stop likely triggered). Removing from state.")
                del pos[s]

    # signal exits
    for s in list(pos):
        if sig[s].iloc[-1]["exit"]:
            broker.cancel_stop(pos[s].get("stop_id"))
            px = broker.sell(s, pos[s]["qty"])
            notify(f"SELL {s} x{pos[s]['qty']} @ ~{px:.2f}")
            del pos[s]

    # trail stops up (never down)
    for s, p in pos.items():
        last = sig[s].iloc[-1]
        new_stop = last.Close - C.ATR_MULT * last.atr
        if new_stop > p["stop"]:
            broker.cancel_stop(p.get("stop_id"))
            p["stop_id"] = broker.place_stop(s, p["qty"], new_stop)
            p["stop"] = new_stop

    # equity / drawdown halt
    value = sum(p["qty"] * sig[s].iloc[-1].Close for s, p in pos.items())
    equity = broker.cash() + value
    state["peak"] = max(state["peak"], equity)
    can_enter = not halted(equity, state["peak"])
    if not can_enter:
        notify(f"Max drawdown hit (equity {equity:,.0f}). No new entries.")

    # entries
    for s in C.SYMBOLS:
        if not can_enter or len(pos) >= C.MAX_POSITIONS:
            break
        if s in pos or not sig[s].iloc[-1]["entry"]:
            continue
        px = D.latest_price(s)
        dist = C.ATR_MULT * sig[s].iloc[-1].atr
        qty = position_size(equity, px, broker.cash(), dist)
        if qty < 1:
            continue
        fill = broker.buy(s, qty)
        stop = fill - dist
        pos[s] = {"qty": qty, "entry": fill, "stop": stop,
                  "stop_id": broker.place_stop(s, qty, stop)}
        notify(f"BUY {s} x{qty} @ ~{fill:.2f}, stop {stop:.2f}")

    state["last_bar"] = bar
    json.dump(state, open(STATE_FILE, "w"), indent=2)
    notify(f"Done. Equity ~{equity:,.0f}, open positions: {list(pos) or 'none'}")


if __name__ == "__main__":
    main()
