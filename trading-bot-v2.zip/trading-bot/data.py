import numpy as np
import pandas as pd


def load(symbol, years=5):
    import yfinance as yf
    df = yf.Ticker(f"{symbol}.NS").history(period=f"{years}y", auto_adjust=True)
    df.index = df.index.tz_localize(None).normalize()
    return df[["Open", "High", "Low", "Close", "Volume"]].dropna()


def load_index(years=7):
    import yfinance as yf
    df = yf.Ticker("^NSEI").history(period=f"{years}y", auto_adjust=True)
    df.index = df.index.tz_localize(None).normalize()
    return df[["Open", "High", "Low", "Close"]].dropna()


def latest_price(symbol):
    import yfinance as yf
    return float(yf.Ticker(f"{symbol}.NS").fast_info["last_price"])


def synthetic(n=1500, seed=0):
    """Fake OHLC data for offline testing only."""
    rng = np.random.default_rng(seed)
    drift = np.where(np.sin(np.arange(n) / 120) > 0, 0.0007, -0.0003)
    close = 100 * np.exp(np.cumsum(drift + rng.normal(0, 0.012, n)))
    open_ = np.r_[close[0], close[:-1]] * (1 + rng.normal(0, 0.003, n))
    high = np.maximum(open_, close) * (1 + abs(rng.normal(0, 0.005, n)))
    low = np.minimum(open_, close) * (1 - abs(rng.normal(0, 0.005, n)))
    idx = pd.bdate_range(end="2026-11-06", periods=n)
    return pd.DataFrame({"Open": open_, "High": high, "Low": low,
                         "Close": close, "Volume": 1e6}, index=idx)
