import os
import data as D


class PaperBroker:
    """Simulated broker. State (cash) lives in the shared state dict."""
    def __init__(self, state):
        self.state = state
        state.setdefault("cash", 0)

    def cash(self):
        return self.state["cash"]

    def buy(self, symbol, qty):
        px = D.latest_price(symbol)
        self.state["cash"] -= qty * px
        return px

    def sell(self, symbol, qty):
        px = D.latest_price(symbol)
        self.state["cash"] += qty * px
        return px

    def place_stop(self, symbol, qty, trigger):
        return None   # paper stops are checked by the bot against daily lows

    def cancel_stop(self, order_id):
        pass

    def held(self):
        return None   # paper: bot tracks everything itself


class KiteBroker:
    """Zerodha Kite Connect adapter. UNTESTED: verify with 1 share before trusting it."""
    def __init__(self, state):
        if os.getenv("CONFIRM_LIVE") != "YES":
            raise SystemExit("Refusing to trade live: set CONFIRM_LIVE=YES to confirm.")
        from kiteconnect import KiteConnect
        self.k = KiteConnect(api_key=os.environ["KITE_API_KEY"])
        self.k.set_access_token(os.environ["KITE_ACCESS_TOKEN"])  # refreshed daily

    def cash(self):
        return self.k.margins()["equity"]["available"]["live_balance"]

    def _order(self, symbol, side, qty, **kw):
        return self.k.place_order(
            variety=self.k.VARIETY_REGULAR, exchange=self.k.EXCHANGE_NSE,
            tradingsymbol=symbol, transaction_type=side, quantity=qty,
            product=self.k.PRODUCT_CNC, **kw)

    def buy(self, symbol, qty):
        self._order(symbol, self.k.TRANSACTION_TYPE_BUY, qty, order_type=self.k.ORDER_TYPE_MARKET)
        return D.latest_price(symbol)   # TODO: read actual fill from order history

    def sell(self, symbol, qty):
        self._order(symbol, self.k.TRANSACTION_TYPE_SELL, qty, order_type=self.k.ORDER_TYPE_MARKET)
        return D.latest_price(symbol)

    def place_stop(self, symbol, qty, trigger):
        return self._order(symbol, self.k.TRANSACTION_TYPE_SELL, qty,
                           order_type=self.k.ORDER_TYPE_SLM, trigger_price=round(round(trigger / 0.05) * 0.05, 2))

    def held(self):
        """Symbols currently held at the broker (holdings + open positions)."""
        h = {x["tradingsymbol"] for x in self.k.holdings()
             if x["quantity"] + x.get("t1_quantity", 0) > 0}
        h |= {x["tradingsymbol"] for x in self.k.positions()["net"] if x["quantity"] > 0}
        return h

    def cancel_stop(self, order_id):
        if order_id:
            self.k.cancel_order(variety=self.k.VARIETY_REGULAR, order_id=order_id)
