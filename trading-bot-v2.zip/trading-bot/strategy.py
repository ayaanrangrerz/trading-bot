import pandas as pd
import config as C


def rsi(close, n):
    d = close.diff()
    up = d.clip(lower=0).ewm(alpha=1 / n, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / n, adjust=False).mean()
    return 100 - 100 / (1 + up / dn)


def atr(df, n):
    pc = df.Close.shift()
    tr = pd.concat([df.High - df.Low, (df.High - pc).abs(), (df.Low - pc).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / n, adjust=False).mean()


def add_signals(df):
    """Adds indicators plus boolean 'entry' / 'exit' evaluated at each close."""
    df = df.copy()
    df["ema_f"] = df.Close.ewm(span=C.EMA_FAST, adjust=False).mean()
    df["ema_s"] = df.Close.ewm(span=C.EMA_SLOW, adjust=False).mean()
    df["sma_t"] = df.Close.rolling(C.SMA_TREND).mean()
    df["rsi"] = rsi(df.Close, C.RSI_PERIOD)
    df["atr"] = atr(df, C.ATR_PERIOD)
    up = (df.ema_f > df.ema_s) & (df.ema_f.shift() <= df.ema_s.shift())
    down = (df.ema_f < df.ema_s) & (df.ema_f.shift() >= df.ema_s.shift())
    warm = pd.Series(range(len(df)), index=df.index) >= C.SMA_TREND
    df["entry"] = up & (df.rsi > C.RSI_MIN) & (df.Close > df.sma_t) & warm
    df["exit"] = down & warm
    return df
