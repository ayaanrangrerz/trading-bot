import os
import config as C


def position_size(equity, price, cash, stop_dist):
    """stop_dist = price distance (INR) between entry and stop."""
    if stop_dist <= 0:
        return 0
    by_risk = equity * C.RISK_PER_TRADE / stop_dist
    by_conc = equity / C.MAX_POSITIONS / price
    by_cash = cash / (price * (1 + C.COST))
    return int(max(0, min(by_risk, by_conc, by_cash)))


def halted(equity, peak):
    return equity < peak * (1 - C.MAX_DRAWDOWN)


def kill_switch():
    """Create a file named KILL in the project folder to stop the bot instantly."""
    return os.path.exists("KILL")
