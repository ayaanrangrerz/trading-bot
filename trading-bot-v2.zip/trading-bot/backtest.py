import sys
import pandas as pd
import config as C
from strategy import add_signals
from risk import position_size
import data as D


def run(data):
    sig = {s: add_signals(d) for s, d in data.items()}
    dates = sorted(set().union(*[set(d.index) for d in sig.values()]))
    cash, pos, trades, curve = C.CAPITAL, {}, [], []
    q_entry, q_exit, last = [], [], {}

    def sell(s, px, dt, why):
        p = pos.pop(s)
        proceeds = p["qty"] * px * (1 - C.COST)
        trades.append({"symbol": s, "entry": p["date"], "exit": dt, "why": why,
                       "pnl": proceeds - p["qty"] * p["entry"] * (1 + C.COST)})
        return proceeds

    for dt in dates:
        # 1) execute yesterday's signals at today's open
        for s in q_exit:
            if s in pos and dt in sig[s].index:
                cash += sell(s, sig[s].at[dt, "Open"] * (1 - C.SLIPPAGE), dt, "signal")
        for s, atr_v in q_entry:
            if s in pos or len(pos) >= C.MAX_POSITIONS or dt not in sig[s].index:
                continue
            px = sig[s].at[dt, "Open"] * (1 + C.SLIPPAGE)
            dist = C.ATR_MULT * atr_v
            eq = cash + sum(p["qty"] * last[k] for k, p in pos.items())
            qty = position_size(eq, px, cash, dist)
            if qty < 1:
                continue
            cash -= qty * px * (1 + C.COST)
            pos[s] = {"qty": qty, "entry": px, "stop": px - dist, "date": dt}
        q_entry, q_exit = [], []
        # 2) intraday stop-losses (gap-down fills at the open)
        for s in list(pos):
            if dt in sig[s].index and sig[s].at[dt, "Low"] <= pos[s]["stop"]:
                px = min(sig[s].at[dt, "Open"], pos[s]["stop"]) * (1 - C.SLIPPAGE)
                cash += sell(s, px, dt, "stop")
        # 3) at the close: mark to market, trail stops, queue tomorrow's orders
        for s, d in sig.items():
            if dt in d.index:
                row = d.loc[dt]
                last[s] = row.Close
                if s in pos:
                    pos[s]["stop"] = max(pos[s]["stop"], row.Close - C.ATR_MULT * row.atr)
                    if row["exit"]:
                        q_exit.append(s)
                elif row["entry"]:
                    q_entry.append((s, row.atr))
        curve.append((dt, cash + sum(p["qty"] * last[k] for k, p in pos.items())))
    eq = pd.Series(dict(curve)).iloc[C.SMA_TREND:]      # skip indicator warm-up
    return eq, pd.DataFrame(trades)


def stats(eq):
    yrs = max((eq.index[-1] - eq.index[0]).days / 365.25, 1e-9)
    ret = eq.iloc[-1] / eq.iloc[0] - 1
    return ret, (1 + ret) ** (1 / yrs) - 1, (eq / eq.cummax() - 1).min()


def trade_stats(tr, start, end):
    t = tr[(tr.exit >= start) & (tr.exit <= end)] if len(tr) else tr
    if not len(t):
        return "0 trades"
    w, l = t[t.pnl > 0].pnl, t[t.pnl <= 0].pnl
    pf = w.sum() / abs(l.sum()) if len(l) and l.sum() != 0 else float("inf")
    return f"{len(t)} trades, win {len(w) / len(t):.0%}, avg win {w.mean() if len(w) else 0:,.0f}, avg loss {l.mean() if len(l) else 0:,.0f}, PF {pf:.2f}"


def report(eq, tr, bench):
    b = bench.reindex(eq.index, method="ffill").dropna()
    b = b / b.iloc[0] * C.CAPITAL
    cut = eq.index[int(len(eq) * C.TRAIN_FRACTION)]
    views = [("FULL", eq.index[0], eq.index[-1]),
             ("TRAIN (first 60%)", eq.index[0], cut),
             ("TEST  (last 40%)", cut, eq.index[-1])]
    print(f"{'':20}{'Period':26}{'Bot ret':>9}{'Bot CAGR':>10}{'Bot MaxDD':>10}   |{'Nifty CAGR':>11}{'Nifty MaxDD':>12}")
    for name, a, z in views:
        e, bb = eq[a:z], b[a:z]
        r, c, d = stats(e)
        br, bc, bd = stats(bb)
        print(f"{name:20}{str(a.date()) + ' -> ' + str(z.date()):26}{r:>9.1%}{c:>10.1%}{d:>10.1%}   |{bc:>11.1%}{bd:>12.1%}")
    print()
    for name, a, z in views:
        print(f"{name:20}{trade_stats(tr, a, z)}")
    print("\nTip: judge the TEST row. Don't change settings after looking at it, that is overfitting.")


def robust(data, bench):
    print("\nRobustness check (results should not swing wildly):")
    orig = C.ATR_MULT
    for k in (2.5, 3.0, 3.5):
        C.ATR_MULT = k
        eq, tr = run(data)
        r, c, d = stats(eq)
        print(f"  ATR_MULT={k}: CAGR {c:.1%}, MaxDD {d:.1%}, trades {len(tr)}")
    C.ATR_MULT = orig


if __name__ == "__main__":
    if "--synthetic" in sys.argv:
        data = {f"SYN{i}": D.synthetic(seed=i) for i in range(6)}
        bench = D.synthetic(seed=99).Close
    else:
        data = {s: D.load(s, C.BACKTEST_YEARS) for s in C.SYMBOLS}
        bench = D.load_index(C.BACKTEST_YEARS).Close
    eq, tr = run(data)
    report(eq, tr, bench)
    if "--robust" in sys.argv:
        robust(data, bench)
