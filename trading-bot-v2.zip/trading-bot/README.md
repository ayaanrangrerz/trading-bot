# NSE Swing Trading Bot (v2)

Daily EMA(20/50) crossover + RSI>50 + 200-day trend filter on Nifty 50 stocks.
Stop = 3x ATR below entry, trailing up. Signals on the close, orders at next open.

## Setup
    pip install -r requirements.txt

## 1. Backtest
    python backtest.py --synthetic    # offline smoke test, fake data
    python backtest.py                # real data + Nifty buy-and-hold comparison + train/test view
    python backtest.py --robust       # also checks ATR_MULT 2.5 / 3 / 3.5
    python test_replay.py             # offline: bot.py makes same trades as backtest.py

Judge the TEST row against Nifty and FD (~6-7%). Don't re-tune after looking at it.

## 2. Paper trade (2-4 weeks minimum)
    MODE=paper python bot.py          # Windows: set MODE=paper  then  python bot.py
Run weekdays after 09:20 IST.

## 3. Live (Zerodha Kite Connect)
    export KITE_API_KEY=... KITE_ACCESS_TOKEN=... CONFIRM_LIVE=YES
    MODE=live python bot.py
KiteBroker is UNTESTED. Token expires daily. Test with 1 share first.
Check your broker's current SEBI algo-trading requirements.

## Safety
- `touch KILL` stops the bot (Windows: `New-Item KILL`). Delete the file to resume.
- Halts new entries after 10% drawdown from peak.
- Only fund the account with money you can afford to lose.
