import os

MODE = os.getenv("MODE", "paper")          # backtest | paper | live

# Liquid Nifty 50 names (Yahoo tickers get ".NS" appended)
SYMBOLS = ["RELIANCE", "TCS", "HDFCBANK", "INFY", "ICICIBANK",
           "ITC", "LT", "SBIN", "BHARTIARTL", "HINDUNILVR"]

# Strategy (v2)
EMA_FAST, EMA_SLOW = 20, 50
RSI_PERIOD, RSI_MIN = 14, 50
SMA_TREND = 200            # only buy when close > 200-day average
ATR_PERIOD = 14
ATR_MULT = 3.0             # stop = entry - 3*ATR, then trails up (never down)

# Risk
CAPITAL = 100_000          # backtest / paper starting capital (INR)
RISK_PER_TRADE = 0.01      # risk 1% of equity per trade (distance to stop)
MAX_POSITIONS = 4
MAX_DRAWDOWN = 0.10        # stop opening new trades if equity falls 10% from peak

# Costs (rough: brokerage + STT + charges, and slippage) per side
COST = 0.001
SLIPPAGE = 0.0005

# Backtest
BACKTEST_YEARS = 7
TRAIN_FRACTION = 0.6       # first 60% = "train" view, last 40% = "test" view

# Alerts (optional)
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")
