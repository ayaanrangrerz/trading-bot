"""Offline consistency test: replays bot.py day by day on fake data and checks it
makes the same trades as backtest.py. Run: python test_replay.py"""
import os, re
import pandas as pd
from datetime import date
import config as C
import data as D

C.COST = C.SLIPPAGE = 0          # compare logic, not costs
C.MODE = "paper"
full = {f"SYN{i}": D.synthetic(seed=i) for i in range(6)}
C.SYMBOLS = list(full)
idx = full["SYN0"].index

import backtest, bot
if os.path.exists(bot.STATE_FILE):
    os.remove(bot.STATE_FILE)


class FakeDate(date):
    _t = None
    @classmethod
    def today(cls):
        return cls._t


bot.date = FakeDate
events = []
bot.notify = lambda m: events.append((FakeDate._t, m))
for i in range(C.SMA_TREND, len(idx)):
    FakeDate._t = idx[i].date()
    D.load = lambda s, years=2, i=i: full[s].loc[:idx[i]]           # includes today's bar; bot must drop it
    D.latest_price = lambda s, i=i: float(full[s].at[idx[i], "Open"])
    bot.main()

eq, tr = backtest.run(full)
bt_entries = {(r.symbol, r.entry.date()) for r in tr.itertuples()}
bt_exits = {(r.symbol, r.exit.date()) for r in tr.itertuples()}
bot_buys = {(m.split()[1], d) for d, m in events if m.startswith("BUY")}
bot_exits = set()
for d, m in events:
    if m.startswith("SELL"):
        bot_exits.add((m.split()[1], d))
    if m.startswith("STOP"):
        bot_exits.add((m.split()[1], date.fromisoformat(m.split()[-1])))

print(f"backtest closed trades: {len(tr)} | bot buys: {len(bot_buys)} | bot exits: {len(bot_exits)}")
print("entries of closed trades all found in bot:", bt_entries <= bot_buys)
print("exits match exactly:", bt_exits == bot_exits)
os.remove(bot.STATE_FILE)
